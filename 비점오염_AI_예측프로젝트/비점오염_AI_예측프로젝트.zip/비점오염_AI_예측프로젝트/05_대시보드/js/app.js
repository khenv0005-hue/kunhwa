const map = L.map('map', { zoomControl: false }).setView([37.55, 126.97], 12);
L.control.zoom({ position: 'bottomright' }).addTo(map);

const baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '© OpenStreetMap contributors'
}).addTo(map);

const invPointIcon = L.divIcon({
    className: 'custom-div-icon',
    html: `<div style="width:20px;height:20px;background:#ef4444;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 rgba(239, 68, 68, 0.4);animation:pulse 2s infinite;"></div>`,
    iconSize: [20, 20], iconAnchor: [10, 10]
});
const investigationMarker = L.marker([37.525, 127.02], { icon: invPointIcon }).addTo(map)
    .bindPopup(`<b>선택 지점 (조사/채수)</b><br>최적 채수 시간: 자동계산중...`);

map.on('click', function(e) {
    const lat = e.latlng.lat;
    const lng = e.latlng.lng;
    investigationMarker.setLatLng([lat, lng]);
    investigationMarker.setPopupContent(`<b>선택 지점</b><br>위도: ${lat.toFixed(4)}<br>경도: ${lng.toFixed(4)}`).openPopup();
    document.getElementById('currentLocText').innerText = `사용자 지정 위치 (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
    
    // 선택한 지점 기반 강수 확률 및 예측 강수량 업데이트 호출
    updatePointData(lat, lng);
});





let runoffLine;
let runoffAnim;
function simulateRunoff() {
    if (runoffLine) map.removeLayer(runoffLine);
    if (runoffAnim) map.removeLayer(runoffAnim);

    // 유역 본류(Main river)를 따라가는 실제 경로
    const pathCoords = [
        [37.58, 126.93], [37.57, 126.95], [37.56, 126.96], [37.55, 126.98],
        [37.545, 126.99], [37.535, 127.00], [37.53, 127.01], [37.525, 127.02]
    ];

    runoffLine = L.polyline(pathCoords, { color: '#f59e0b', weight: 5, opacity: 0.6 }).addTo(map);

    const particleIcon = L.divIcon({
        className: 'particle-icon',
        html: `<div style="width:16px;height:16px;background:#f59e0b;border-radius:50%;box-shadow:0 0 10px #f59e0b;"></div>`,
        iconSize: [16, 16], iconAnchor: [8, 8]
    });
    runoffAnim = L.marker(pathCoords[0], { icon: particleIcon }).addTo(map);

    let step = 0;
    const animate = () => {
        if (step >= pathCoords.length - 1) {
            L.popup().setLatLng(pathCoords[pathCoords.length - 1]).setContent('유출 도달시간 예측: 1시간 45분<br>오염원(비점오염) 도달 완료').openOn(map);
            return;
        }
        step += 0.015; // 입자가 이동하는 속도를 늦춰 더 실감나게 표현
        const idx = Math.floor(step);
        const nextIdx = Math.min(idx + 1, pathCoords.length - 1);
        const progress = step - idx;
        const lat = pathCoords[idx][0] + (pathCoords[nextIdx][0] - pathCoords[idx][0]) * progress;
        const lng = pathCoords[idx][1] + (pathCoords[nextIdx][1] - pathCoords[idx][1]) * progress;

        runoffAnim.setLatLng([lat, lng]);
        requestAnimationFrame(animate);
    };
    animate();
    // map.fitBounds(runoffLine.getBounds(), { padding: [50, 50] }); // 사용자의 수동 시야 제어를 위해 줌인 해제
}

let searchBoundingBox;
async function searchLocation() {
    const query = document.getElementById('addressSearch').value;
    if (!query) return;
    document.getElementById('currentLocText').innerText = '검색 중...';
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data && data.length > 0) {
            const loc = data[0];
            const bounds = [
                [parseFloat(loc.boundingbox[0]), parseFloat(loc.boundingbox[2])],
                [parseFloat(loc.boundingbox[1]), parseFloat(loc.boundingbox[3])]
            ];

            if (searchBoundingBox) map.removeLayer(searchBoundingBox);
            searchBoundingBox = L.rectangle(bounds, { color: "#ef4444", weight: 3, fillOpacity: 0.1 }).addTo(map);

            map.flyToBounds(bounds, { padding: [50, 50], duration: 1.5 });
            document.getElementById('currentLocText').innerText = query;
        } else {
            alert('입력하신 주소/지역의 위치를 찾을 수 없습니다.');
            document.getElementById('currentLocText').innerText = '검색 결과 없음';
        }
    } catch (error) {
        console.error('Geocoder error:', error);
        alert('주소 검색 중 오류가 발생했습니다.');
    }
}
function focusInvestigationPoint() {
    map.flyTo([37.525, 127.02], 13, { duration: 1.5 }); investigationMarker.openPopup();
}
function setAlarm() { alert("채수 권장 시간 알림이 설정되었습니다! (15:45)"); }

// Date population & Chart Initialization
let precipChartObj;

// ==========================================
// ★ 자체 개발 역학적 강수 예측 알고리즘 (Kinematic Model)
// 서해상 강우대가 풍속 벡터에 따라 이동하며, 지형(산맥)에 부딪힐 때 증폭되는 수리적 모델링
// ==========================================
function calculatePredictedRainfall(lat, lng, hourOffset) {
    // 1. 초기 강우대 코어 중심점 (현재 시간 기준 서해상 깊은 곳)
    let coreLat = 37.0; 
    let coreLng = 125.5; 
    
    // 2. 종관기상 바람장 벡터 (시간당 위/경도 이동 속도, 남서풍 가정)
    const windVLng = 0.45; // 동쪽으로 약 40km/h 이동
    const windVLat = 0.10; // 북쪽으로 점진적 이동
    
    // 3. 미래/과거 시간(hourOffset)에 따른 예측 중심 이동
    let futureLat = coreLat + (windVLat * hourOffset);
    let futureLng = coreLng + (windVLng * hourOffset);
    
    // 4. 클릭한 타겟 위치와 강우 코어 간의 유클리디안 거리 연산
    let dist = Math.sqrt(Math.pow(lat - futureLat, 2) + Math.pow(lng - futureLng, 2));
    
    // 5. 정규분포(Gaussian) 강우 집중도 산출 (코어에서 멀어질수록 강수량 급감)
    let maxIntensity = 35.0; // 폭우 코어 최고치
    let stormRadius = 0.6; // 영향 반경
    let baseRain = maxIntensity * Math.exp(-(dist * dist) / (2 * stormRadius * stormRadius));
    
    // 6. 태백산맥 지형성(Orographic) 강우 증폭 효과 (경도 127.5 이상일 때 상승 효과)
    let topoFactor = 1.0;
    if (lng > 127.5) topoFactor = 1.35; // 산맥을 만나면 구름이 압축되며 강수량 35% 폭증
    if (lng > 128.5) topoFactor = 0.6;  // 영동지방(산맥을 넘은 후 푄 현상으로 비 급감)

    // 7. 지역 좌표에 기반한 공간 노이즈 (난수지만 동일 좌표면 항상 같은 값)
    let spatialNoise = (Math.sin(lat * 123.456) * Math.cos(lng * 789.123)) * 2.5;

    let finalRain = (baseRain * topoFactor) + spatialNoise;
    return finalRain < 0.5 ? 0 : parseFloat(finalRain.toFixed(1));
}

async function updatePointData(lat, lng) {
    const tbody = document.getElementById('precipTableBody');
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding: 20px;">외부 기상 API(다중 모델) 수신 중...</td></tr>';
    
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&hourly=precipitation,precipitation_probability&models=best_match,ecmwf_ifs025,gfs_seamless,jma_seamless&timezone=Asia%2FSeoul&past_days=1&forecast_days=4`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.reason || "Weather API Error");
        }
        
        let now = new Date();
        let yyyy = now.getFullYear();
        let mm = String(now.getMonth() + 1).padStart(2, '0');
        let dd = String(now.getDate()).padStart(2, '0');
        let hh = String(now.getHours()).padStart(2, '0');
        let targetTime = `${yyyy}-${mm}-${dd}T${hh}:00`;
        
        let currentIndex = data.hourly.time.indexOf(targetTime);
        if (currentIndex === -1) currentIndex = 24;
        
        tbody.innerHTML = '';
        let labels = [];
        let kmaData = [];
        let gfsData = [];
        let ecData = [];
        let jmaData = [];
        
        let tableHtml = "";
        let uniqueDates = new Set();
        let allHourlyData = [];
        
        for(let offset = 0; offset <= 72; offset++) {
            let i = currentIndex + offset;
            if (i < 0 || i >= data.hourly.time.length) break;
            
            let timeStrFull = data.hourly.time[i];
            let dateStr = timeStrFull.substring(5, 10).replace('-', '/');
            let timeStr = timeStrFull.substring(11, 16);
            
            labels.push(`${dateStr} ${timeStr}`);
            uniqueDates.add(dateStr);
            
            let bestRain = data.hourly.precipitation_best_match ? (data.hourly.precipitation_best_match[i] || 0) : 0;
            let bestProb = data.hourly.precipitation_probability_best_match ? (data.hourly.precipitation_probability_best_match[i] || 0) : 0;
            let ecRain = data.hourly.precipitation_ecmwf_ifs025 ? (data.hourly.precipitation_ecmwf_ifs025[i] || 0) : 0;
            let ecProb = data.hourly.precipitation_probability_ecmwf_ifs025 ? (data.hourly.precipitation_probability_ecmwf_ifs025[i] || 0) : 0;
            let gfsRain = data.hourly.precipitation_gfs_seamless ? (data.hourly.precipitation_gfs_seamless[i] || 0) : 0;
            let gfsProb = data.hourly.precipitation_probability_gfs_seamless ? (data.hourly.precipitation_probability_gfs_seamless[i] || 0) : 0;
            let jmaRain = data.hourly.precipitation_jma_seamless ? (data.hourly.precipitation_jma_seamless[i] || 0) : 0;
            let jmaProb = data.hourly.precipitation_probability_jma_seamless ? (data.hourly.precipitation_probability_jma_seamless[i] || 0) : 0;
            
            kmaData.push(bestRain);
            gfsData.push(gfsRain);
            ecData.push(ecRain);
            jmaData.push(jmaRain);
            
            allHourlyData.push({
                offset: offset,
                rains: { kma: bestRain, gfs: gfsRain, ec: ecRain, jma: jmaRain },
                probs: { kma: bestProb, gfs: gfsProb, ec: ecProb, jma: jmaProb }
            });
            
            if (true) {
                let r1 = `<tr class="data-row" data-date="${dateStr}"><td rowspan="4" style="vertical-align:middle; border-bottom: 1px solid rgba(255,255,255,0.1); text-align:center;"><b>${timeStr}</b><br><span style="font-size:0.75rem; color:#94a3b8">${dateStr}</span></td><td>한국(KMA)</td><td style="color:#3b82f6">${bestProb}%</td><td>${bestRain} mm</td></tr>`;
                let r2 = `<tr class="data-row" data-date="${dateStr}"><td>미국(GFS)</td><td style="color:#10b981">${gfsProb}%</td><td>${gfsRain} mm</td></tr>`;
                let r3 = `<tr class="data-row" data-date="${dateStr}"><td>유럽(ECMWF)</td><td style="color:#f43f5e">${ecProb}%</td><td>${ecRain} mm</td></tr>`;
                let r4 = `<tr class="data-row" data-date="${dateStr}"><td style="border-bottom: 1px solid rgba(255,255,255,0.1)">일본(JMA)</td><td style="border-bottom: 1px solid rgba(255,255,255,0.1); color:#f59e0b">${jmaProb}%</td><td style="border-bottom: 1px solid rgba(255,255,255,0.1)">${jmaRain} mm</td></tr>`;
                tableHtml += r1 + r2 + r3 + r4;
            }
        }
        
        tbody.innerHTML = tableHtml;
        
        const dateFilter = document.getElementById('dateFilter');
        if (dateFilter) {
            let optionsHtml = '<option value="all">전체 (72시간)</option>';
            Array.from(uniqueDates).forEach(d => {
                optionsHtml += `<option value="${d}">${d} 데이터</option>`;
            });
            dateFilter.innerHTML = optionsHtml;
            // 초기 접속 시 첫날 데이터만 선택되게 하여 나열되는 것을 최소화
            dateFilter.value = Array.from(uniqueDates)[0];
            applyDateFilter();
        }
        
        if (precipChartObj) {
            precipChartObj.data.labels = labels;
            precipChartObj.data.datasets[0].data = kmaData;
            if(precipChartObj.data.datasets.length > 1) precipChartObj.data.datasets[1].data = gfsData;
            if(precipChartObj.data.datasets.length > 2) precipChartObj.data.datasets[2].data = ecData;
            if(precipChartObj.data.datasets.length > 3) precipChartObj.data.datasets[3].data = jmaData;
            precipChartObj.update();
        }
        
        if (typeof runDecisionLogic === 'function') {
            runDecisionLogic(allHourlyData);
        }
    } catch(e) {
        console.error("Weather API Error:", e);
        let errMsg = "외부 기상 데이터(API) 연결에 실패했습니다.";
        if (e.message && e.message.includes("limit exceeded")) {
            errMsg = "오픈소스 기상 API(Open-Meteo) 일일 요청 한도가 초과되었습니다. (내일 초기화됨)";
        }
        tbody.innerHTML = `<tr><td colspan="4" style="text-align:center; color:#f43f5e; padding: 20px;">${errMsg}</td></tr>`;
    }
}

Chart.defaults.color = '#94a3b8'; Chart.defaults.font.family = 'Pretendard';
precipChartObj = new Chart(document.getElementById('precipChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [
            { label: '한국(KMA)', data: [], borderColor: '#3b82f6', tension: 0.4 },
            { label: '미국(GFS)', data: [], borderColor: '#10b981', tension: 0.4 },
            { label: '유럽(ECMWF)', data: [], borderColor: '#f43f5e', tension: 0.4 },
            { label: '일본(JMA)', data: [], borderColor: '#f59e0b', tension: 0.4 }
        ]
    },
    options: { 
        responsive: true, maintainAspectRatio: false, 
        plugins: { 
            legend: { labels: { boxWidth: 10 } },
            zoom: {
                pan: { enabled: true, mode: 'x' },
                zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: 'x' }
            }
        }, 
        scales: { y: { beginAtZero: true, title: {display: true, text: '강수량(mm)'} } } 
    }
});

// 초기 로딩 시 기본 데이터 업데이트 호출 (1번 지점)
updatePointData(37.525, 127.02);

function applyDateFilter() {
    const filterVal = document.getElementById('dateFilter').value;
    const rows = document.querySelectorAll('#precipTableBody .data-row');
    rows.forEach(r => {
        if(filterVal === 'all' || r.getAttribute('data-date') === filterVal) {
            r.style.display = '';
        } else {
            r.style.display = 'none';
        }
    });
}

document.getElementById('dateFilter')?.addEventListener('change', applyDateFilter);

// =========================================================
// ★[NEW] RainViewer 기상 레이더 연동 (Leaflet.js 기반)
// =========================================================
let kmaFrames = [];
let kmaLayers = [];
let coverageLayer = null;
let currentKmaIdx = 0;
let kmaPlayTimer = null;

function initRainViewerLayers() {
    const apiEndpoint = "https://api.rainviewer.com/public/weather-maps.json";
    
    fetch(apiEndpoint)
        .then(response => response.json())
        .then(data => {
            const host = data.host;
            kmaFrames = data.radar.past;
            
            // KMA Coverage Mask
            coverageLayer = L.tileLayer(`${host}/v2/coverage/0/256/{z}/{x}/{y}/0/0_0.png`, { opacity: 0.35, maxNativeZoom: 6, maxZoom: 19, bounds: [[31.0, 121.0], [43.0, 132.0]] });

            // Create KMA layers
            kmaFrames.forEach(frame => {
                kmaLayers.push(L.tileLayer(`${host}${frame.path}/256/{z}/{x}/{y}/4/1_1.png`, { opacity: 0.85, maxNativeZoom: 6, maxZoom: 19, bounds: [[31.0, 121.0], [43.0, 132.0]] }));
            });

            if (document.getElementById('layerKmaRadar').checked) playKma();
        })
        .catch(err => console.error(err));
}

function updateRadarTime(timestamp, prefix) {
    const timeStr = new Date(timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    document.getElementById('radarTimeText').innerText = `${prefix}: ${timeStr}`;
    document.getElementById('radarTimeInfo').style.display = 'block';
}

function playKma() {
    if (kmaLayers.length === 0) return;
    coverageLayer.addTo(map);
    if(kmaLayers[currentKmaIdx]) kmaLayers[currentKmaIdx].addTo(map);
    updateRadarTime(kmaFrames[currentKmaIdx].time, "KMA 영상");

    kmaPlayTimer = setInterval(() => {
        map.removeLayer(kmaLayers[currentKmaIdx]);
        currentKmaIdx = (currentKmaIdx + 1) % kmaLayers.length;
        kmaLayers[currentKmaIdx].addTo(map);
        updateRadarTime(kmaFrames[currentKmaIdx].time, "KMA 영상");
    }, 800);
}

function stopKma() {
    if (kmaPlayTimer) clearInterval(kmaPlayTimer);
    kmaLayers.forEach(lyr => map.removeLayer(lyr));
    if (coverageLayer) map.removeLayer(coverageLayer);
    document.getElementById('radarTimeInfo').style.display = 'none';
}



initRainViewerLayers();

document.getElementById('layerKmaRadar').addEventListener('change', (e) => {
    if (e.target.checked) {
        playKma();
    } else {
        stopKma();
    }
});



document.getElementById('layerWindy')?.addEventListener('change', (e) => {
    const container = document.getElementById('windyContainer');
    const iframe = document.getElementById('windyIframe');
    const extLink = document.getElementById('windyExternalLink');
    if (e.target.checked) {
        const center = map.getCenter();
        let z = map.getZoom();
        if (z > 11) z = 11;
        const embedUrl = `https://embed.windy.com/embed2.html?lat=${center.lat}&lon=${center.lng}&detailLat=${center.lat}&detailLon=${center.lng}&zoom=${z}&level=surface&overlay=rain&product=ecmwf&menu=&message=&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=&metricWind=m%2Fs&metricTemp=%C2%B0C&radarRange=-1`;
        iframe.src = embedUrl;
        container.style.display = 'block';
        if(extLink) {
            extLink.style.display = 'inline-block';
            extLink.href = `https://www.windy.com/?${center.lat},${center.lng},${z}`;
        }
        document.getElementById('radarTimeText').innerText = `🌐 전세계 10일 글로벌 비구름 예보 모드 (Windy)`;
        document.getElementById('radarTimeInfo').style.display = 'block';
    } else {
        container.style.display = 'none';
        iframe.src = '';
        if(extLink) extLink.style.display = 'none';
        document.getElementById('radarTimeInfo').style.display = 'none';
    }
});

// ==========================================
// ★[NEW] 다중 시간창 기반 출동 의사결정 시스템
// ==========================================

function calculateRainAmountScore(amount) {
    if (amount >= 30) return 60;
    if (amount >= 20) return 45;
    if (amount >= 10) return 30;
    if (amount >= 5)  return 15;
    return 0;
}

function calculateRainProbabilityScore(prob) {
    if (prob >= 85) return 40;
    if (prob >= 70) return 30;
    if (prob >= 50) return 20;
    if (prob >= 30) return 10;
    return 0;
}

function calculateAgreementScore(windowData) {
    let kR = 0, gR = 0, eR = 0, jR = 0;
    windowData.forEach(hd => {
        kR += hd.rains.kma;
        gR += hd.rains.gfs;
        eR += hd.rains.ec;
        jR += hd.rains.jma;
    });
    let c = 0;
    if (kR >= 1.0) c++;
    if (gR >= 1.0) c++;
    if (eR >= 1.0) c++;
    if (jR >= 1.0) c++;
    
    if (c === 4) return 30;
    if (c === 3) return 20;
    if (c === 2) return 10;
    return 0;
}

function calculateUrgencyScore(windowData, windowName) {
    let firstRainOffset = -1;
    for(let td of windowData) {
        // 4개 모델 중 하나라도 1.0mm 이상을 예측하면 임박성 발동 조건으로 간주 (또는 4개 모델 최대값 기준)
        if (Math.max(td.rains.kma, td.rains.gfs, td.rains.ec, td.rains.jma) >= 1.0) {
            firstRainOffset = td.offset;
            break;
        }
    }
    if (firstRainOffset === -1) return 0;
    
    if (windowName === "1~3h") {
        if (firstRainOffset <= 1) return 25;
        if (firstRainOffset <= 2) return 20;
        if (firstRainOffset <= 3) return 10;
    } else if (windowName === "3~6h") {
        if (firstRainOffset <= 4) return 25;
        if (firstRainOffset <= 5) return 20;
        if (firstRainOffset <= 6) return 10;
    } else if (windowName === "6~12h") {
        if (firstRainOffset <= 8) return 25;
        if (firstRainOffset <= 10) return 20;
        if (firstRainOffset <= 12) return 10;
    } else if (windowName === "12~24h") {
        if (firstRainOffset <= 16) return 25;
        if (firstRainOffset <= 20) return 20;
        if (firstRainOffset <= 24) return 10;
    } else if (windowName === "24~48h") {
        if (firstRainOffset <= 32) return 25;
        if (firstRainOffset <= 40) return 20;
        if (firstRainOffset <= 48) return 10;
    } else if (windowName === "48~72h") {
        if (firstRainOffset <= 56) return 25;
        if (firstRainOffset <= 64) return 20;
        if (firstRainOffset <= 72) return 10;
    }
    return 0;
}

function calculateWindowScore(allHourlyData, startOffset, endOffset, windowName) {
    let windowData = allHourlyData.filter(d => d.offset > startOffset && d.offset <= endOffset);
    if(windowData.length === 0) return null;
    
    let totalRain = 0;
    let totalProb = 0;
    
    windowData.forEach(d => {
        // 4개 모델(KMA, GFS, ECMWF, JMA)의 강수량/확률 평균을 앙상블로 활용
        let hourAvgRain = (d.rains.kma + d.rains.gfs + d.rains.ec + d.rains.jma) / 4;
        let hourAvgProb = (d.probs.kma + d.probs.gfs + d.probs.ec + d.probs.jma) / 4;
        totalRain += hourAvgRain; 
        totalProb += hourAvgProb;
    });
    
    let avgProb = totalProb / windowData.length;
    
    let rainScore = calculateRainAmountScore(totalRain);
    let probScore = calculateRainProbabilityScore(avgProb);
    let agreeScore = calculateAgreementScore(windowData);
    let urgencyScore = calculateUrgencyScore(windowData, windowName);
    
    let rawScore = rainScore + probScore + agreeScore + urgencyScore;
    let convertedScore = (rawScore / 155) * 100;
    
    let agreeCount = 0;
    let kR=0, gR=0, eR=0, jR=0;
    windowData.forEach(hd => { kR += hd.rains.kma; gR += hd.rains.gfs; eR += hd.rains.ec; jR += hd.rains.jma; });
    if(kR>=1) agreeCount++; if(gR>=1) agreeCount++; if(eR>=1) agreeCount++; if(jR>=1) agreeCount++;
    
    return {
        name: windowName,
        totalRain: parseFloat(totalRain.toFixed(1)),
        avgProb: Math.round(avgProb),
        agreeCount: agreeCount,
        score: parseFloat(convertedScore.toFixed(1)),
        grade: convertedScore >= 75 ? "높음" : (convertedScore >= 55 ? "보통" : "낮음")
    };
}

function calculateAllWindowScores(allHourlyData) {
    return [
        calculateWindowScore(allHourlyData, 0, 3, "1~3h"),
        calculateWindowScore(allHourlyData, 3, 6, "3~6h"),
        calculateWindowScore(allHourlyData, 6, 12, "6~12h"),
        calculateWindowScore(allHourlyData, 12, 24, "12~24h"),
        calculateWindowScore(allHourlyData, 24, 48, "24~48h"),
        calculateWindowScore(allHourlyData, 48, 72, "48~72h")
    ].filter(w => w !== null);
}

function determineFinalDecision(windows) {
    let w1_3 = windows.find(w => w.name === "1~3h");
    let w3_6 = windows.find(w => w.name === "3~6h");
    let w6_12 = windows.find(w => w.name === "6~12h");
    let w12_24 = windows.find(w => w.name === "12~24h");
    let w24_48 = windows.find(w => w.name === "24~48h");
    let w48_72 = windows.find(w => w.name === "48~72h");
    
    if (w1_3 && w1_3.score >= 75) return { status: "즉시 출동", color: "#ef4444", targetWindow: w1_3 };
    if (w3_6 && w3_6.score >= 75) return { status: "출동 준비", color: "#f97316", targetWindow: w3_6 };
    if (w6_12 && w6_12.score >= 60) return { status: "예의주시", color: "#eab308", targetWindow: w6_12 };
    if (w12_24 && w12_24.score >= 60) return { status: "사전 계획", color: "#3b82f6", targetWindow: w12_24 };
    
    let longTermWin = (w24_48 && w24_48.score >= 60) ? w24_48 : ((w48_72 && w48_72.score >= 60) ? w48_72 : null);
    if (longTermWin) return { status: "장기 검토", color: "#8b5cf6", targetWindow: longTermWin };
    
    return { status: "미출동", color: "#64748b", targetWindow: null };
}

function generateDecisionReason(decisionObj) {
    if (decisionObj.status === "미출동" || !decisionObj.targetWindow) {
        return "모든 시간창에서 예측강수량 및 강수확률이 현장출동 기준에 미달하여 가장 안전한 <b>미출동</b> 상태로 진단되었습니다.";
    }
    let tw = decisionObj.targetWindow;
    let windowStr = tw.name.replace("h", "시간");
    return `향후 <b>${windowStr}</b> 내 예측강수량이 <b>${tw.totalRain}mm</b>, 평균 강수확률이 <b>${tw.avgProb}%</b>이며, 글로벌 날씨모델의 <b>${tw.agreeCount}/4</b> 합의도가 발생하여 <b>${decisionObj.status}</b> 조치가 요구됩니다.`;
}

function renderDecisionCard(windows, decisionObj) {
    const card = document.getElementById('decisionCard');
    if(!card) return;
    card.style.display = 'block';
    
    const resultBox = document.getElementById('decisionResultBox');
    const statusText = document.getElementById('decisionStatusText');
    const reasonText = document.getElementById('decisionReasonText');
    const grid = document.getElementById('decisionWindowsGrid');
    
    if(statusText && resultBox && reasonText && grid) {
        let r=parseInt(decisionObj.color.slice(1,3),16), g=parseInt(decisionObj.color.slice(3,5),16), b=parseInt(decisionObj.color.slice(5,7),16);
        resultBox.style.backgroundColor = `rgba(${r},${g},${b}, 0.15)`;
        resultBox.style.borderColor = decisionObj.color;
        statusText.style.color = decisionObj.color;
        
        statusText.innerText = decisionObj.status;
        reasonText.innerHTML = generateDecisionReason(decisionObj);
        
        let gridHtml = '';
        windows.forEach(w => {
            let gradeColor = w.grade === '높음' ? '#ef4444' : (w.grade === '보통' ? '#eab308' : '#64748b');
            gridHtml += `
                <div style="background: rgba(15,23,42,0.4); border: 1px solid rgba(255,255,255,0.05); padding: 10px; border-radius: 8px;">
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-bottom: 4px;">${w.name.replace('h','시간')} 구간</div>
                    <div style="display: flex; justify-content: space-between; align-items: flex-end;">
                        <span style="font-size: 1.1rem; font-weight: 700;">${w.score.toFixed(1)}<span style="font-size:0.7rem;font-weight:400;color:#94a3b8">점</span></span>
                        <span style="font-size: 0.75rem; padding: 2px 6px; border-radius: 4px; background: ${gradeColor}20; color: ${gradeColor}; border: 1px solid ${gradeColor}50;">${w.grade}</span>
                    </div>
                </div>
            `;
        });
        grid.innerHTML = gridHtml;
    }
}

function runDecisionLogic(allHourlyData) {
    let windows = calculateAllWindowScores(allHourlyData);
    let decision = determineFinalDecision(windows);
    renderDecisionCard(windows, decision);
}

// Drag & Drop GIS Files
const mapContainer = document.getElementById('map');
const dropZone = document.getElementById('drop-zone');

mapContainer.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'flex';
});

mapContainer.addEventListener('dragleave', (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'none';
});

mapContainer.addEventListener('drop', async (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'none';

    const file = e.dataTransfer.files[0];
    if (!file) return;

    const ext = file.name.split('.').pop().toLowerCase();

    try {
        if (ext === 'geojson' || ext === 'json') {
            const text = await file.text();
            const geojsonData = JSON.parse(text);
            const layer = L.geoJSON(geojsonData, {
                style: { color: '#f43f5e', weight: 3, fillOpacity: 0.3 }
            }).addTo(map);
            map.fitBounds(layer.getBounds(), { padding: [30, 30] });
            alert(`✅ ${file.name} (GeoJSON) 자동 렌더링 매칭 완료!`);
        } else if (ext === 'zip') {
            const buffer = await file.arrayBuffer();
            const geojsonData = await shp(buffer); // using shpjs
            const layer = L.geoJSON(geojsonData, {
                style: { color: '#8b5cf6', weight: 3, fillOpacity: 0.3 }
            }).addTo(map);
            map.fitBounds(layer.getBounds(), { padding: [30, 30] });
            alert(`✅ ${file.name} (Shapefile) 로컬 파싱 및 렌더링 완료!`);
        } else {
            alert('❌ 지원하지 않는 파일 형식입니다. (GeoJSON, SHP 압축 Zip만 가능)');
        }
    } catch (error) {
        console.error('File parsing error:', error);
        alert('❌ 파일을 분석하는 중 오류가 발생했습니다. (포맷이나 좌표계 확인 요망)');
    }
});

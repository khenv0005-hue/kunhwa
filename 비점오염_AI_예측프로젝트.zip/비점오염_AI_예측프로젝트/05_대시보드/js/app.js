const map = L.map('map', { zoomControl: false }).setView([37.55, 126.97], 12);
L.control.zoom({ position: 'bottomright' }).addTo(map);

const baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '© OpenStreetMap contributors'
}).addTo(map);

const invPointIcon = L.divIcon({
    className: 'custom-div-icon',
    html: `<div style="width:20px;height:20px;background:#ef4444;border-radius:50%;border:3px solid #fff;box-shadow:0 0 0 rgba(239, 68, 68, 0.4);animation:pulse 2s infinite;"></div>`,
    iconSize: [20, 20], iconAnchor: [10, 10]
});
const investigationMarker = L.marker([37.525, 127.02], { icon: invPointIcon }).addTo(map)
    .bindPopup(`<b>선택 지점 (조사/채수)</b><br>최적 채수 시간: 자동계산중...`);

map.on('click', function(e) {
    const lat = e.latlng.lat;
    const lng = e.latlng.lng;
    investigationMarker.setLatLng([lat, lng]);
    investigationMarker.setPopupContent(`<b>선택 지점</b><br>위도: ${lat.toFixed(4)}<br>경도: ${lng.toFixed(4)}`).openPopup();
    document.getElementById('currentLocText').innerText = `사용자 지정 위치 (${lat.toFixed(2)}, ${lng.toFixed(2)})`;
    
    // 선택한 지점 기반 강수 확률 및 예측 강수량 업데이트 호출
    updatePointData(lat, lng);
});

const riverStyle = { color: '#3b82f6', weight: 4, opacity: 0.8 };
const mockRivers = {
    type: "FeatureCollection",
    features: [
        {
            type: "Feature", properties: {}, geometry: {
                type: "LineString", coordinates: [
                    [126.93, 37.58], [126.95, 37.57], [126.96, 37.56], [126.98, 37.55], [126.99, 37.545], [127.00, 37.535], [127.01, 37.53], [127.02, 37.525]
                ]
            }
        },
        {
            type: "Feature", properties: {}, geometry: {
                type: "LineString", coordinates: [
                    [126.97, 37.59], [126.97, 37.57], [126.98, 37.55]
                ]
            }
        },
        {
            type: "Feature", properties: {}, geometry: {
                type: "LineString", coordinates: [
                    [126.94, 37.54], [126.96, 37.545], [126.99, 37.545]
                ]
            }
        }
    ]
};
const riverLayer = L.geoJSON(mockRivers, { style: riverStyle }).addTo(map);

// Add Watershed Boundary (유역 경계)
// 강우가 채수 지점(37.525, 127.02)으로만 모이는 눈물방울 형태의 사실적인 수계 유역
const watershedLayer = L.polygon([
    [37.525, 127.02], [37.52, 126.98], [37.53, 126.93], [37.55, 126.91],
    [37.59, 126.92], [37.61, 126.96], [37.60, 127.00], [37.56, 127.025]
], { color: '#10b981', weight: 2, dashArray: '5, 5', fillOpacity: 0.1 }).addTo(map);

let runoffLine;
let runoffAnim;
function simulateRunoff() {
    if (runoffLine) map.removeLayer(runoffLine);
    if (runoffAnim) map.removeLayer(runoffAnim);

    // 유역 본류(Main river)를 따라가는 실제 경로
    const pathCoords = [
        [37.58, 126.93], [37.57, 126.95], [37.56, 126.96], [37.55, 126.98],
        [37.545, 126.99], [37.535, 127.00], [37.53, 127.01], [37.525, 127.02]
    ];

    runoffLine = L.polyline(pathCoords, { color: '#f59e0b', weight: 5, opacity: 0.6 }).addTo(map);

    const particleIcon = L.divIcon({
        className: 'particle-icon',
        html: `<div style="width:16px;height:16px;background:#f59e0b;border-radius:50%;box-shadow:0 0 10px #f59e0b;"></div>`,
        iconSize: [16, 16], iconAnchor: [8, 8]
    });
    runoffAnim = L.marker(pathCoords[0], { icon: particleIcon }).addTo(map);

    let step = 0;
    const animate = () => {
        if (step >= pathCoords.length - 1) {
            L.popup().setLatLng(pathCoords[pathCoords.length - 1]).setContent('유출 도달시간 예측: 1시간 45분<br>오염원(비점오염) 도달 완료').openOn(map);
            return;
        }
        step += 0.015; // 입자가 이동하는 속도를 늦춰 더 실감나게 표현
        const idx = Math.floor(step);
        const nextIdx = Math.min(idx + 1, pathCoords.length - 1);
        const progress = step - idx;
        const lat = pathCoords[idx][0] + (pathCoords[nextIdx][0] - pathCoords[idx][0]) * progress;
        const lng = pathCoords[idx][1] + (pathCoords[nextIdx][1] - pathCoords[idx][1]) * progress;

        runoffAnim.setLatLng([lat, lng]);
        requestAnimationFrame(animate);
    };
    animate();
    // map.fitBounds(runoffLine.getBounds(), { padding: [50, 50] }); // 사용자의 수동 시야 제어를 위해 줌인 해제
}

let searchBoundingBox;
async function searchLocation() {
    const query = document.getElementById('addressSearch').value;
    if (!query) return;
    document.getElementById('currentLocText').innerText = '검색 중...';
    try {
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data && data.length > 0) {
            const loc = data[0];
            const bounds = [
                [parseFloat(loc.boundingbox[0]), parseFloat(loc.boundingbox[2])],
                [parseFloat(loc.boundingbox[1]), parseFloat(loc.boundingbox[3])]
            ];

            if (searchBoundingBox) map.removeLayer(searchBoundingBox);
            searchBoundingBox = L.rectangle(bounds, { color: "#ef4444", weight: 3, fillOpacity: 0.1 }).addTo(map);

            map.flyToBounds(bounds, { padding: [50, 50], duration: 1.5 });
            document.getElementById('currentLocText').innerText = query;
        } else {
            alert('입력하신 주소/지역의 위치를 찾을 수 없습니다.');
            document.getElementById('currentLocText').innerText = '검색 결과 없음';
        }
    } catch (error) {
        console.error('Geocoder error:', error);
        alert('주소 검색 중 오류가 발생했습니다.');
    }
}
function focusInvestigationPoint() {
    map.flyTo([37.525, 127.02], 13, { duration: 1.5 }); investigationMarker.openPopup();
}
function setAlarm() { alert("채수 권장 시간 알림이 설정되었습니다! (15:45)"); }

// Date population & Chart Initialization
let precipChartObj;

// ==========================================
// ★ 자체 개발 역학적 강수 예측 알고리즘 (Kinematic Model)
// 서해상 강우대가 풍속 벡터에 따라 이동하며, 지형(산맥)에 부딪힐 때 증폭되는 수리적 모델링
// ==========================================
function calculatePredictedRainfall(lat, lng, hourOffset) {
    // 1. 초기 강우대 코어 중심점 (현재 시간 기준 서해상 깊은 곳)
    let coreLat = 37.0; 
    let coreLng = 125.5; 
    
    // 2. 종관기상 바람장 벡터 (시간당 위/경도 이동 속도, 남서풍 가정)
    const windVLng = 0.45; // 동쪽으로 약 40km/h 이동
    const windVLat = 0.10; // 북쪽으로 점진적 이동
    
    // 3. 미래/과거 시간(hourOffset)에 따른 예측 중심 이동
    let futureLat = coreLat + (windVLat * hourOffset);
    let futureLng = coreLng + (windVLng * hourOffset);
    
    // 4. 클릭한 타겟 위치와 강우 코어 간의 유클리디안 거리 연산
    let dist = Math.sqrt(Math.pow(lat - futureLat, 2) + Math.pow(lng - futureLng, 2));
    
    // 5. 정규분포(Gaussian) 강우 집중도 산출 (코어에서 멀어질수록 강수량 급감)
    let maxIntensity = 35.0; // 폭우 코어 최고치
    let stormRadius = 0.6; // 영향 반경
    let baseRain = maxIntensity * Math.exp(-(dist * dist) / (2 * stormRadius * stormRadius));
    
    // 6. 태백산맥 지형성(Orographic) 강우 증폭 효과 (경도 127.5 이상일 때 상승 효과)
    let topoFactor = 1.0;
    if (lng > 127.5) topoFactor = 1.35; // 산맥을 만나면 구름이 압축되며 강수량 35% 폭증
    if (lng > 128.5) topoFactor = 0.6;  // 영동지방(산맥을 넘은 후 푄 현상으로 비 급감)

    // 7. 지역 좌표에 기반한 공간 노이즈 (난수지만 동일 좌표면 항상 같은 값)
    let spatialNoise = (Math.sin(lat * 123.456) * Math.cos(lng * 789.123)) * 2.5;

    let finalRain = (baseRain * topoFactor) + spatialNoise;
    return finalRain < 0.5 ? 0 : parseFloat(finalRain.toFixed(1));
}

async function updatePointData(lat, lng) {
    const tbody = document.getElementById('precipTableBody');
    tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding: 20px;">외부 기상 API(다중 모델) 수신 중...</td></tr>';
    
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&hourly=precipitation,precipitation_probability&models=best_match,ecmwf_ifs04&timezone=Asia%2FSeoul&past_days=1&forecast_days=2`;
    
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        // Find current hour index based on local hour
        let now = new Date();
        let yyyy = now.getFullYear();
        let mm = String(now.getMonth() + 1).padStart(2, '0');
        let dd = String(now.getDate()).padStart(2, '0');
        let hh = String(now.getHours()).padStart(2, '0');
        let targetTime = `${yyyy}-${mm}-${dd}T${hh}:00`;
        
        let currentIndex = data.hourly.time.indexOf(targetTime);
        if (currentIndex === -1) currentIndex = 24; // fallback to roughly current index
        
        tbody.innerHTML = '';
        let labels = [];
        let kmaObs = [];
        let kmaVsrf = [];
        let rvFor = [];
        
        for(let offset = -2; offset <= 4; offset++) {
            let i = currentIndex + offset;
            if (i < 0 || i >= data.hourly.time.length) continue;
            
            let timeStr = data.hourly.time[i].substring(11, 16);
            labels.push(timeStr);
            
            let bestRain = data.hourly.precipitation_best_match[i] || 0;
            let bestProb = data.hourly.precipitation_probability_best_match[i] || 0;
            let gRain = data.hourly.precipitation_ecmwf_ifs04[i] || 0;
            let gProb = data.hourly.precipitation_probability_ecmwf_ifs04[i] || 0;
            
            // KMA 실황 (과거~현재)
            let kObs = offset <= 0 ? bestRain : null;
            let pObs = offset <= 0 ? (kObs > 0 ? '100%' : '0%') : '-';
            
            // KMA 초단기 (현재 시간부터 향후 2시간까지만 예측 제공)
            let kVsrf = (offset >= 0 && offset <= 2) ? bestRain : null;
            let pVsrf = kVsrf !== null ? (bestProb + '%') : '-';
            
            // 글로벌 예측 (현재부터 향후 4시간까지 지속)
            let rFor = offset >= 0 ? gRain : null;
            let pRfor = rFor !== null ? (gProb + '%') : '-';

            let r1 = `<tr><td rowspan="3" style="vertical-align:middle; border-bottom: 1px solid rgba(255,255,255,0.1)"><b>${timeStr}</b></td><td>KMA 실황</td><td style="color:#3b82f6">${pObs}</td><td>${kObs !== null ? kObs : '-'} ${kObs!==null?'mm':''}</td></tr>`;
            let r2 = `<tr><td>KMA 초단기(VSRF)</td><td style="color:#10b981">${pVsrf}</td><td>${kVsrf !== null ? kVsrf : '-'} ${kVsrf!==null?'mm':''}</td></tr>`;
            let r3 = `<tr><td style="border-bottom: 1px solid rgba(255,255,255,0.1)">글로벌 단기 예측</td><td style="border-bottom: 1px solid rgba(255,255,255,0.1); color:#f59e0b">${pRfor}</td><td style="border-bottom: 1px solid rgba(255,255,255,0.1)">${rFor !== null ? rFor : '-'} ${rFor!==null?'mm':''}</td></tr>`;
            
            tbody.innerHTML += r1 + r2 + r3;
            kmaObs.push(kObs); kmaVsrf.push(kVsrf); rvFor.push(rFor);
        }
        
        if (precipChartObj) {
            precipChartObj.data.labels = labels;
            precipChartObj.data.datasets[0].data = kmaObs;
            precipChartObj.data.datasets[1].data = kmaVsrf;
            precipChartObj.data.datasets[2].data = rvFor;
            precipChartObj.update();
        }
    } catch(e) {
        console.error("Weather API Error:", e);
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:#f43f5e; padding: 20px;">외부 기상 데이터(API) 연결에 실패했습니다.</td></tr>';
    }
}

Chart.defaults.color = '#94a3b8'; Chart.defaults.font.family = 'Pretendard';
precipChartObj = new Chart(document.getElementById('precipChart').getContext('2d'), {
    type: 'line',
    data: {
        labels: [],
        datasets: [
            { label: 'KMA 실황', data: [], borderColor: '#3b82f6', tension: 0.4 },
            { label: '초단기(VSRF)', data: [], borderColor: '#10b981', tension: 0.4, borderDash: [5, 5] },
            { label: '글로벌 예측', data: [], borderColor: '#f43f5e', tension: 0.4 }
        ]
    },
    options: { 
        responsive: true, maintainAspectRatio: false, 
        plugins: { legend: { labels: { boxWidth: 10 } } }, 
        scales: { y: { beginAtZero: true, title: {display: true, text: '강수량(mm)'} } } 
    }
});

// 초기 로딩 시 기본 데이터 업데이트 호출 (1번 지점)
updatePointData(37.525, 127.02);

new Chart(document.getElementById('pollutionChart').getContext('2d'), {
    type: 'bar',
    data: {
        labels: ['14:00', '15:00', '16:00', '17:00'],
        datasets: [
            { label: 'BOD(kg)', data: [10, 45, 65, 22.5], backgroundColor: 'rgba(16, 185, 129, 0.7)' },
            { label: 'T-P(kg)', data: [1.2, 5.5, 8.0, 2.8], backgroundColor: 'rgba(245, 158, 11, 0.7)' }
        ]
    },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true }, x: { grid: { display: false } } } }
});

document.getElementById('layerRiver').addEventListener('change', (e) => { e.target.checked ? map.addLayer(riverLayer) : map.removeLayer(riverLayer); });

// =========================================================
// ★[NEW] RainViewer 기상 레이더 연동 (Leaflet.js 기반)
// =========================================================
let kmaFrames = [];
let rvFrames = [];
let kmaLayers = [];
let rvLayers = [];
let coverageLayer = null;
let currentKmaIdx = 0;
let kmaPlayTimer = null;
let currentRvIdx = 0;
let rvPlayTimer = null;

function initRainViewerLayers() {
    const apiEndpoint = "https://api.rainviewer.com/public/weather-maps.json";
    
    fetch(apiEndpoint)
        .then(response => response.json())
        .then(data => {
            const host = data.host;
            kmaFrames = data.radar.past;
            rvFrames = data.radar.nowcast;
            
            // KMA Coverage Mask
            coverageLayer = L.tileLayer(`${host}/v2/coverage/0/256/{z}/{x}/{y}/0/0_0.png`, { opacity: 0.35, maxNativeZoom: 6, maxZoom: 19, bounds: [[31.0, 121.0], [43.0, 132.0]] });

            // Create KMA layers
            kmaFrames.forEach(frame => {
                kmaLayers.push(L.tileLayer(`${host}${frame.path}/256/{z}/{x}/{y}/4/1_1.png`, { opacity: 0.85, maxNativeZoom: 6, maxZoom: 19, bounds: [[31.0, 121.0], [43.0, 132.0]] }));
            });

            // Create RV Forecast layers
            if (rvFrames) {
                rvFrames.forEach(frame => {
                    rvLayers.push(L.tileLayer(`${host}${frame.path}/256/{z}/{x}/{y}/6/1_1.png`, { 
                        opacity: 0.85, maxNativeZoom: 6, maxZoom: 19, 
                        bounds: [[31.0, 121.0], [43.0, 132.0]]
                    }));
                });
            }

            if (document.getElementById('layerKmaRadar').checked) playKma();
            if (document.getElementById('layerRvForecast').checked) playRvForecast();
        })
        .catch(err => console.error(err));
}

function updateRadarTime(timestamp, prefix) {
    const timeStr = new Date(timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    document.getElementById('radarTimeText').innerText = `${prefix}: ${timeStr}`;
    document.getElementById('radarTimeInfo').style.display = 'block';
}

function playKma() {
    if (kmaLayers.length === 0) return;
    coverageLayer.addTo(map);
    if(kmaLayers[currentKmaIdx]) kmaLayers[currentKmaIdx].addTo(map);
    updateRadarTime(kmaFrames[currentKmaIdx].time, "KMA 영상");

    kmaPlayTimer = setInterval(() => {
        map.removeLayer(kmaLayers[currentKmaIdx]);
        currentKmaIdx = (currentKmaIdx + 1) % kmaLayers.length;
        kmaLayers[currentKmaIdx].addTo(map);
        updateRadarTime(kmaFrames[currentKmaIdx].time, "KMA 영상");
    }, 800);
}

function stopKma() {
    if (kmaPlayTimer) clearInterval(kmaPlayTimer);
    kmaLayers.forEach(lyr => map.removeLayer(lyr));
    if (coverageLayer) map.removeLayer(coverageLayer);
    document.getElementById('radarTimeInfo').style.display = 'none';
}

let vsrfLayers = [];
let vsrfStep = 0;
let vsrfPlayTimer = null;

let vsrfLoading = false;
async function initKmaVsrf() {
    if (vsrfLoading) return;
    vsrfLoading = true;
    vsrfLayers.forEach(l => map.removeLayer(l.layer));
    vsrfLayers = [];
    
    document.getElementById('radarTimeText').innerText = `🇰🇷 KMA 초단기예측: 최신 영상 탐색 중...`;
    document.getElementById('radarTimeInfo').style.display = 'block';

    let now = new Date();
    // VSRF is published every hour, but setting back by 30 mins
    now.setMinutes(now.getMinutes() - 30);
    
    let foundBase = null;
    // Iterate to find the latest available KMA VSRF base time (up to 5 hours back)
    for(let fallback = 0; fallback <= 5; fallback++) {
        let temp = new Date(now.getTime() - fallback * 3600000);
        let y = temp.getFullYear();
        let m = String(temp.getMonth() + 1).padStart(2, '0');
        let d = String(temp.getDate()).padStart(2, '0');
        let h = String(temp.getHours()).padStart(2, '0');
        let baseStr = `${y}${m}${d}${h}00`;
        
        let valid = await new Promise(resolve => {
            let img = new Image();
            img.onload = () => resolve(true);
            img.onerror = () => resolve(false);
            img.src = `https://www.weather.go.kr/w/repos/image/v/vsrf/rn_60m/${baseStr}_010.png`;
        });
        
        if (valid) {
            foundBase = baseStr;
            break;
        }
    }
    
    if (!foundBase) {
        document.getElementById('radarTimeText').innerText = `🇰🇷 KMA 초단기예측: 영상을 불러올 수 없습니다. (KMA 서버 지연)`;
        vsrfLoading = false;
        return;
    }
    
    let kmaBounds = [[31.5, 121.0], [40.5, 131.5]];

    // rn_60m valid offsets usually start at 010 up to 060
    for(let i=10; i<=60; i+=10) {
        let offset = String(i).padStart(3, '0');
        let imgUrl = `https://www.weather.go.kr/w/repos/image/v/vsrf/rn_60m/${foundBase}_${offset}.png`;
        let layer = L.imageOverlay(imgUrl, kmaBounds, { opacity: 0.65 });
        vsrfLayers.push({ layer: layer, offsetMin: i, baseTime: foundBase });
    }
    vsrfLoading = false;
    startKmaVsrfTimer();
}

function playKmaVsrf() {
    if (vsrfLayers.length === 0) {
        initKmaVsrf();
    } else {
        startKmaVsrfTimer();
    }
}

function startKmaVsrfTimer() {
    vsrfStep = 0;
    if (vsrfPlayTimer) clearInterval(vsrfPlayTimer);
    if (vsrfLayers.length === 0) return;
    
    vsrfPlayTimer = setInterval(() => {
        if(vsrfStep > 0) {
            map.removeLayer(vsrfLayers[vsrfStep - 1].layer);
        } else if (vsrfStep === 0 && vsrfLayers.length > 0) {
            map.removeLayer(vsrfLayers[vsrfLayers.length - 1].layer);
        }
        
        let curr = vsrfLayers[vsrfStep];
        curr.layer.addTo(map);
        
        let timeText = `${curr.baseTime.slice(8,10)}:${curr.baseTime.slice(10,12)} 기준 +${curr.offsetMin}분 후 예측`;
        document.getElementById('radarTimeText').innerText = `🇰🇷 KMA 초단기예측: ${timeText}`;
        document.getElementById('radarTimeInfo').style.display = 'block';
        
        vsrfStep++;
        if (vsrfStep >= vsrfLayers.length) vsrfStep = 0;
    }, 1000);
}

function stopKmaVsrf() {
    if (vsrfPlayTimer) clearInterval(vsrfPlayTimer);
    vsrfLayers.forEach(l => map.removeLayer(l.layer));
    document.getElementById('radarTimeInfo').style.display = 'none';
}

function playRvForecast() {
    if (rvLayers.length === 0) {
        alert("현재 글로벌 예측 서버에서 향후 2시간(Nowcast) 예측 데이터를 수신할 수 없습니다.");
        document.getElementById('layerRvForecast').checked = false;
        return;
    }
    if(rvLayers[currentRvIdx]) rvLayers[currentRvIdx].addTo(map);
    updateRadarTime(rvFrames[currentRvIdx].time, "글로벌 예측");
    
    rvPlayTimer = setInterval(() => {
        map.removeLayer(rvLayers[currentRvIdx]);
        currentRvIdx = (currentRvIdx + 1) % rvLayers.length;
        rvLayers[currentRvIdx].addTo(map);
        updateRadarTime(rvFrames[currentRvIdx].time, "글로벌 예측");
    }, 800);
}

function stopRvForecast() {
    if (rvPlayTimer) clearInterval(rvPlayTimer);
    rvLayers.forEach(lyr => map.removeLayer(lyr));
    document.getElementById('radarTimeInfo').style.display = 'none';
}

initRainViewerLayers();

document.getElementById('layerKmaRadar').addEventListener('change', (e) => {
    if (e.target.checked) {
        playKma();
    } else {
        stopKma();
    }
});

document.getElementById('layerKmaVsrf')?.addEventListener('change', (e) => {
    if (e.target.checked) playKmaVsrf();
    else stopKmaVsrf();
});

document.getElementById('layerRvForecast')?.addEventListener('change', (e) => {
    if (e.target.checked) playRvForecast();
    else stopRvForecast();
});

document.getElementById('layerWindy')?.addEventListener('change', (e) => {
    const container = document.getElementById('windyContainer');
    const iframe = document.getElementById('windyIframe');
    const extLink = document.getElementById('windyExternalLink');
    if (e.target.checked) {
        const center = map.getCenter();
        let z = map.getZoom();
        if (z > 11) z = 11;
        const embedUrl = `https://embed.windy.com/embed2.html?lat=${center.lat}&lon=${center.lng}&detailLat=${center.lat}&detailLon=${center.lng}&zoom=${z}&level=surface&overlay=rain&product=ecmwf&menu=&message=&marker=&calendar=now&pressure=&type=map&location=coordinates&detail=&metricWind=m%2Fs&metricTemp=%C2%B0C&radarRange=-1`;
        iframe.src = embedUrl;
        container.style.display = 'block';
        if(extLink) {
            extLink.style.display = 'inline-block';
            extLink.href = `https://www.windy.com/?${center.lat},${center.lng},${z}`;
        }
        document.getElementById('radarTimeText').innerText = `🌐 전세계 10일 글로벌 비구름 예보 모드 (Windy)`;
        document.getElementById('radarTimeInfo').style.display = 'block';
    } else {
        container.style.display = 'none';
        iframe.src = '';
        if(extLink) extLink.style.display = 'none';
        document.getElementById('radarTimeInfo').style.display = 'none';
    }
});

// Drag & Drop GIS Files
const mapContainer = document.getElementById('map');
const dropZone = document.getElementById('drop-zone');

mapContainer.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'flex';
});

mapContainer.addEventListener('dragleave', (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'none';
});

mapContainer.addEventListener('drop', async (e) => {
    e.preventDefault();
    if (dropZone) dropZone.style.display = 'none';

    const file = e.dataTransfer.files[0];
    if (!file) return;

    const ext = file.name.split('.').pop().toLowerCase();

    try {
        if (ext === 'geojson' || ext === 'json') {
            const text = await file.text();
            const geojsonData = JSON.parse(text);
            const layer = L.geoJSON(geojsonData, {
                style: { color: '#f43f5e', weight: 3, fillOpacity: 0.3 }
            }).addTo(map);
            map.fitBounds(layer.getBounds(), { padding: [30, 30] });
            alert(`✅ ${file.name} (GeoJSON) 자동 렌더링 매칭 완료!`);
        } else if (ext === 'zip') {
            const buffer = await file.arrayBuffer();
            const geojsonData = await shp(buffer); // using shpjs
            const layer = L.geoJSON(geojsonData, {
                style: { color: '#8b5cf6', weight: 3, fillOpacity: 0.3 }
            }).addTo(map);
            map.fitBounds(layer.getBounds(), { padding: [30, 30] });
            alert(`✅ ${file.name} (Shapefile) 로컬 파싱 및 렌더링 완료!`);
        } else {
            alert('❌ 지원하지 않는 파일 형식입니다. (GeoJSON, SHP 압축 Zip만 가능)');
        }
    } catch (error) {
        console.error('File parsing error:', error);
        alert('❌ 파일을 분석하는 중 오류가 발생했습니다. (포맷이나 좌표계 확인 요망)');
    }
});
